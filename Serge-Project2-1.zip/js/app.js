//Add Search student filter for dynamically search students
  //Add a div .student-search
  //Add input with innerText "Search for students..."
  //Add button with innerText "Search"
var getDivParentNode = document.getElementsByTagName("div")[1];
//var createDiv;
var studentList = document.querySelector(".student-list");
var studentItems = document.querySelectorAll(".student-item");
var studentListParent = studentList.parentNode;
//Student list array
var getStudentList = document.querySelectorAll("h3");
var studentsArray = studentList;
var studentListChildren = studentList.childNodes;
var buttonSelect;
var addUl = document.createElement("ul");
var paginationDiv;
var itemsPerPage = 10;
var getPageNumbers;

var getPage;
// var pageNumber = Math.ceil(getStudentList.length / itemsPerPage)
var createElement = function() {
  var createDiv = document.createElement("div");
  var createInput = document.createElement("input");
  createInput.placeholder = "Search for students...";
  var createButton = document.createElement("button");
  createButton.innerText = "Search";
  
  createDiv.classList.add("student-search");
  createDiv.appendChild(createInput);
  createDiv.appendChild(createButton);
  studentSearch = createDiv.getElementsByTagName("input")[0]
  buttonSelect = createDiv.querySelector("button");
  //Append createdDiv to the second div
  getDivParentNode.appendChild(createDiv);
}

//Call function when search is clicked (addEventListener("change", ....))
var getStudent = function() {
  console.log("Button clicked...")
  for (var i = 0; i < getStudentList.length; i += 1) {
    var student;
    if (getStudentList[i].innerText == studentSearch.value.toLowerCase()) {
      console.log("Matched Student....");
      student = document.getElementsByTagName("li")[i]
      console.log(i);
      studentListParent.removeChild(studentList);
      console.log(student);
      addUl.classList.add("student-list");
      //Append created ul to studentListParent
      studentListParent.appendChild(addUl);
      //Append student to created ul
      addUl.appendChild(student);
    }
  }
}

//Create pagination buttons with numbers 10 students per page.
var createPages = function() {
  var pageNumber = Math.ceil(getStudentList.length / itemsPerPage)
  var getDivParentNode = document.getElementsByTagName("div")[0]
  //Create Div .pagination
  paginationDiv = document.createElement("div");
  paginationDiv.classList.add("pagination");
  //Create an unordered list for the page buttons
  var addUl = document.createElement("ul");

  for (var i = 1; i <= pageNumber; i += 1) {
    //Created list items for the pages
    var pageListItem = document.createElement("li");
    //Create anchor tags
    var pageNumberAnchor = document.createElement("a");
    pageNumberAnchor.href = "#";
    pageNumberAnchor.innerText = i;
    pageListItem.appendChild(pageNumberAnchor);
    addUl.appendChild(pageListItem);
  }
  paginationDiv.appendChild(addUl);
  getDivParentNode.appendChild(paginationDiv);
}

//When the page loads show the first 10 students and add the other students
//When a user click on "2" in the pagination, students 11 through 20 are shown
//When a user clicks on "3", students 21 through 30 are shown, an so on
// var selectPage = function() {
//   console.log("page number selected");
// }

function selectPage(index) {
  return function() {
    console.log("you click page " + index);
    var createStudentsArray;
    var select = getPageNumbers[index];

    for (var i = 0; i < getPageNumbers.length; i += 1) {
      getPageNumbers[i].classList.remove("active");
      removeListItems();
    }
    select.classList.add("active");

    if ((select.innerText - 1) == index){
      console.log("Yay Got It!!!!!");
      //When a user click on "2" in the pagination, students 11 through 20 are shown
      var firstStudentOnPage = index * 10;
      var lastStudentOnPage = firstStudentOnPage + 9;


      console.log(firstStudentOnPage + " - " + lastStudentOnPage)
      
      displayTenStudents(firstStudentOnPage, lastStudentOnPage);
    }
  }  
}
//Append 10 students to the list and display 10 students based on selected page
function displayTenStudents(firstStudentOnPage, lastStudentOnPage) {
  var selected = [];
  for (var i = firstStudentOnPage; i < lastStudentOnPage; i += 1) {
    if (i < getStudentList.length) {
      studentList.appendChild(studentItems[i]);
    } else {
      break;
    }
  }
}

//Clears the student list items
function removeListItems() {
  for (var i = 1; i < studentListChildren.length; i += 1){
    studentList.removeChild(studentListChildren[i])
    // Show first 10 students
  }
  return studentList;
}

var displayStudents = function() {
  var activeStudent = paginationDiv.getElementsByTagName("a")[0];
  var firstStudent = 0;
  var tenthStudent = 9;
  //Remove the original list of all students
  removeListItems();
  //Add only the first 10 students
  displayTenStudents(firstStudent, tenthStudent);
  activeStudent.classList.add("active");
  //Get an array of the buttons anchor element
  getPageNumbers = paginationDiv.querySelectorAll("a");
  for (var i = 0; i < getPageNumbers.length; i += 1) {
    getPageNumbers[i].addEventListener("click", selectPage(i));
  }
}

createElement();
buttonSelect.addEventListener("click", getStudent);
createPages();
displayStudents();

//Create a button on 10 students per page
  //Add appropriate number of button links at the botton of the page
    //Get the number of ul li items array.length/10 and ceil















